<?php
declare(strict_types=1);

return [
    'db' => [
        'host' => '127.0.0.1',
        'name' => 'rame_it',
        'user' => 'root',
        'password' => '',
    ],
    'app_url' => 'http://localhost/Rame/public',
    'timezone' => 'America/Mexico_City',
    'encryption_key' => 'SsKJPjKrjNwUJc96rQZQDzVwyfgjMt5DPVVWm4CEzl0=',
    'smtp' => [
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'username' => '',
        'password' => '',
        'from_email' => '',
        'from_name' => 'Rame TI',
        'encryption' => 'tls',
    ],
];